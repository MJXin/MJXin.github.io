//
//  MyObject.h
//  NSObjectTest
//
//  Created by 马家欣 on 2020/8/27.
//  Copyright © 2020 马家欣. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyObject : NSObject

@end

NS_ASSUME_NONNULL_END
