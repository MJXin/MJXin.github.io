//
//  MyObject.m
//  NSObjectTest
//
//  Created by 马家欣 on 2020/8/27.
//  Copyright © 2020 马家欣. All rights reserved.
//

#import "MyObject.h"

@implementation MyObject

@end
