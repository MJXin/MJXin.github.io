//
//  MySubObject.m
//  NSObjectTest
//
//  Created by 马家欣 on 2020/8/27.
//  Copyright © 2020 马家欣. All rights reserved.
//

#import "MySubObject.h"

@implementation MySubObject
//- (instancetype)init{
//    if(self = [super init]) {
//        self->bcb = 10;
//    }
//    return self;
//}
@end
