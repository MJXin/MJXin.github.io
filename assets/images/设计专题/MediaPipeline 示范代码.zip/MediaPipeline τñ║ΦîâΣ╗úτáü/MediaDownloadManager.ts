import {DeviceEventEmitter} from 'react-native'
import MediaPipelineTask from 'SERVICES/mediaPipeline/MediaPipelineTask'
import MediaPipeline, {MediaPipelineType, MediaPipelineTypeSteps} from 'SERVICES/mediaPipeline/MediaPipeline'
import {MediaPipelineErrorCode} from 'SERVICES/mediaPipeline/MediapipelineError'
import FileManager from 'SERVICES/fileSystem/FileManager'
import {debugLog, errorLog, taskErrorLog, taskLog, warningLog} from "./Log"
import DBManager from 'SERVICES/dataBase/DBManager'
import MediaDownloadRecord from 'SERVICES/dataBase/model/MediaDownloadRecord'
import {MediaPipelineStepType} from "SERVICES/mediaPipeline"
import {ZMap} from 'TYPES/Map'
import store from 'STORE'
import {ConnectMode} from 'SERVICES/grpc/Types/ConnectMode'

interface MediaDownloadParams {
  previewPath?: string
}

// tasks 数组发生增减通知（对数组进行增删同时需要发送消息通知外界， 暂时只能手动实现，没对长度进行监听）
export const MediaDownloadManagerTasksDidChangedNotify = "MediaDownloadManagerTasksDidChangedNotify"

/**
 * 视频下载队列的管理器, 不与业务逻辑绑定,只提供下载操作接口
 * 业务管理类为 MediaDownloadServices
 * TODO:目前命名有歧义,之后做更改,当前版上线前修改风险太大
 */
class MediaDownloadManager {

  private downloadable = true
  private tasks: MediaPipelineTask[] = []
  private pipelines: ZMap<MediaPipelineType, MediaPipeline> = {
    [MediaPipelineType.WiFiDownloadAndWriteVideo]: MediaPipeline.pipeLine(MediaPipelineType.WiFiDownloadAndWriteVideo),
    [MediaPipelineType.WiFiDownloadAndWritePhoto]: MediaPipeline.pipeLine(MediaPipelineType.WiFiDownloadAndWritePhoto),
    [MediaPipelineType.WiFiWriteVideoWithPreview]: MediaPipeline.pipeLine(MediaPipelineType.WiFiWriteVideoWithPreview),
    [MediaPipelineType.WiFiDownloadAndUpdateVideo]: MediaPipeline.pipeLine(MediaPipelineType.WiFiDownloadAndUpdateVideo),
    //删掉了
  }

  public readonly switchDownloadable = (downloadable: boolean) => {
    debugLog("switchDownloadAble: ", downloadable)
    this.downloadable = downloadable
    if (!downloadable) this.pauseAllTask()
  }

  /**
   * 通过名字获取某个 task
   */
  public readonly getTask = (mediaName: string): MediaPipelineTask | undefined => {
    return this.tasks.find(task => task.mediaName == mediaName)
  }

  /**
   * 返回下载中的视频任务
   */
  public readonly getVideoTasks = (sort?: (a: MediaPipelineTask, b: MediaPipelineTask) => number) => {
    return this.tasks.filter(
      task => task.pipeLineType == MediaPipelineType.WiFiDownloadAndUpdateVideo ||
        task.pipeLineType == MediaPipelineType.WiFiDownloadAndWriteVideo
    ).sort(sort)
  }

  /**
   * 返回所有下载任务
   */
  public readonly getTasks = (sort?: (a: MediaPipelineTask, b: MediaPipelineTask) => number) => {
    return this.tasks.sort(sort)
  }

  //MARK: - Add Task

  /**
   * 从 MediaServer 下载图片和缩率图并写入数据库
   */
  public downloadAndAddPhotoRecord = (mediaName: string): MediaPipelineTask => {
    debugLog("DownloadAndAddPhotoRecord with mediaName:", mediaName)
    if (store.getState().hover.connectState.mode == ConnectMode.WiFi) {
      return this.addTask(mediaName, MediaPipelineType.WiFiDownloadAndWritePhoto)
    } else {
      return this.addTask(mediaName, MediaPipelineType.USBDownloadAndWritePhoto)
    }
  }

  /**
   * 从 MediaServer 下载视频缩率图并保存预览流写入数据库
   */
  public downloadAndAddVideoRecordWithPreview = (mediaName: string, previewPath?: string): MediaPipelineTask => {
    debugLog("DownloadAndAddVideoRecordWithPreview with mediaName:", mediaName)
    if (store.getState().hover.connectState.mode == ConnectMode.WiFi) {
      return this.addTask(mediaName, MediaPipelineType.WiFiWriteVideoWithPreview, {previewPath: previewPath})
    } else {
      return this.addTask(mediaName, MediaPipelineType.USBWriteVideoWithPreview, {previewPath: previewPath})
    }
  }

  //MARK: - Task Control

  /**
   * 从数据库中还原所有需要执行的 task
   * 需要在最开始的时候执行
   */
  public restoreTasks = () => {
    let mediaDownloadRecords = DBManager.allMediaDownloadRecordsOrderByDate()
    this.tasks = mediaDownloadRecords.map(MediaPipelineTask.taskFromRecord)
    DeviceEventEmitter.emit("MediaDownloadManagerTasksDidChangedNotify")
    debugLog("RestoreTasks from Database :", this.tasks)
  }

  /**
   * 根据名称恢复 tasks
   */
  public resumeTasks = (mediaNames: string[]) => {
    mediaNames.forEach(mediaName => {
      let task = this.getTask(mediaName)
      if (task == undefined) {
        warningLog(`resumeTasks: 无法在当前 tasks 队列中找到 mediaName == ${mediaName} 的 task`)
      } else {
        this.resumeTask(task)
      }
    })
  }

  /**
   * 恢复所有 task
   */
  public resumeAllTask = () => {
    this.tasks.forEach(this.resumeTask)
  }

  /**
   *  暂停指定类型的下载任务
   */
  public pauseTasksWitPipelineType = (type: MediaPipelineType) => {
    this.tasks.filter(task => task.pipeLineType == type).forEach(task => task.pause && task.pause())
  }

  /**
   * 根据 mediaName 暂停 task
   */
  public pauseTasks = (mediaNames: string[]) => {
    mediaNames.forEach(mediaName => {
      let task = this.getTask(mediaName)
      if (task == undefined) {
        warningLog(`pauseTasks: 无法在当前 tasks 队列中找到 mediaName == ${mediaName} 的 task`)
      } else {
        task.pause && task.pause()
      }
    })
  }

  /**
   * 暂停所有 task
   */
  public pauseAllTask = () => {
    this.tasks.forEach((task) => {
      task.pause && task.pause()
    })
  }

  /**
   * 移除指定 mediaName 的 task
   */
  public removeTasks = (mediaNames: string[]) => {
    mediaNames.forEach(mediaName => {
      let task = this.getTask(mediaName)
      if (task == undefined) {
        warningLog(`pauseTasks: 无法在当前 tasks 队列中找到 mediaName == ${mediaName} 的 task`)
      } else {
        task.cancel && task.cancel()
        this.cleanUpTask(task)
      }
    })
  }

  /**
   * 移除队列中的所有 task
   */
  public removeAllTask = () => {
    this.tasks.forEach((task) => {
      task.cancel && task.cancel()
    })
  }

  //MARK: - Private

  /**
   * 恢复 Task 执行
   * ( 内部专用， 内部默认入参需要是已经在队列中的 task，若要开放给外部，需要保证 task 有合理的校验)
   */
  private resumeTask = (task: MediaPipelineTask) => {
    let pipeLine = this.pipelines[task.pipeLineType]
    if (pipeLine == undefined ||
      pipeLine.stepsForTask == undefined) {
      errorLog("Resume, but pipeLine is invaild", pipeLine)
      return
    }
    this.runAndSubscribeTask(task, pipeLine)
    return task
  }

  /**
   * 新增加载任务，若不存在则会创建一个
   *
   * @private
   * @param {string} mediaName
   * @param {MediaPipelineType} type
   * @param {MediaDownloadParams} params
   * @returns {MediaPipelineTask}
   * @memberof MediaDownloadManager
   */
  private addTask = (mediaName: string, type: MediaPipelineType, params?: MediaDownloadParams): MediaPipelineTask => {
    if (this.checkInProgressDuplication(mediaName)) {
      debugLog(`Task ${mediaName} is existed`)
      return this.getTask(mediaName)!
    }
    debugLog("Add MediaPipeline Task:", mediaName)
    let pipeLine = this.pipelines[type]
    let dbRecord = this.insertDownloadRecordIfNeed(mediaName, type)
    let task = MediaPipelineTask.taskFromRecord(dbRecord)
    if (params) {
      task.context.previewTempPath = params.previewPath
    }
    this.runAndSubscribeTask(task, pipeLine)
    this.addTaskAndEmit(task)
    return task
  }

  private insertDownloadRecordIfNeed = (mediaName: string, type: MediaPipelineType): MediaDownloadRecord => {
    let record = DBManager.queryMediaDownloadRecordWithName(mediaName)
    return record ? record : DBManager.insertMediaDownloadRecord(new MediaDownloadRecord(mediaName, type))
  }

  /**
   * 运行并监听 Task 的状态变化
   *
   * @private
   * @memberof MediaDownloadManager
   */
  private runAndSubscribeTask = (task: MediaPipelineTask, pipeLine: MediaPipeline) => {
    if (!this.downloadable) {
      errorLog("runAndSubscribeTask Error: run task when download disable")
      return
    }
    task.runInPipeline(pipeLine).subscribe({
      next: (state) => {
        debugLog(`Update task = ${task.taskID} dataBaseRecord`)
        DBManager.updateDownloadRecord(task.taskID, {
          mediaName: task.mediaName,
          pipeLineType: task.pipeLineType,
          currentStep: state.stepType,
          currentStepProgress: state.stepProgress ? state.stepProgress : 0,
          context: state.context
        })
      },
      error: errorCode => {
        this.dealWithTaskError(task, errorCode)
      },
      complete: () => {
        this.completeTask(task)
      },
    })
  }

  /**
   * task 完成后的结束流程
   *
   * @private
   * @param {MediaPipelineTask} task
   * @memberof MediaDownloadManager
   */
  private completeTask = (task: MediaPipelineTask) => {
    taskLog(task, "Task Completed")
    this.cleanUpTask(task)
  }

  /**
   * task 异常的处理流程
   *
   * @private
   * @param {MediaPipelineTask} task
   * @param {MediaPipelineErrorCode} errorCode
   * @memberof MediaDownloadManager
   */
  private dealWithTaskError = (task: MediaPipelineTask, errorCode: MediaPipelineErrorCode) => {
    if (errorCode != MediaPipelineErrorCode.pause) {
      // 若是出现异常了，则报错并清理现场
      taskErrorLog(task, 'finish with error: ' + errorCode)
      this.cleanUpTask(task)
    } else {
      //若是取消了，则直接结束
      taskErrorLog(task, 'stop with error: ' + errorCode)
    }
  }

  /**
   * 查看对应的任务是否已经存在
   */
  private checkInProgressDuplication = (mediaName: string) => {
    return this.tasks.find(existedTask => existedTask.mediaName === mediaName)
  }

  /**
   * 清空 task 现场
   */
  private cleanUpTask = (task: MediaPipelineTask) => {
    task.currentStage.updateCurrentStage(MediaPipelineStepType.CleanUpAddMediaTask)
    this.removeTaskAndEmit(task)
    let {context} = task
    // 下面的方法会把 MediaPipeline 过程中的临时文件都删除
    // 注意！！！ 最终存放路径不要和临时文件的路径一样，否则会被删掉
    if (context.thumbnailDownloadedPath) {
      taskLog(task, `cleanUpTask deleteFromPath path ${context.thumbnailDownloadedPath}`)
      FileManager.deleteFromPath(context.thumbnailDownloadedPath)
    }
    if (context.originDownloadedPath) {
      taskLog(task, `cleanUpTask deleteFromPath path ${context.originDownloadedPath}`)
      FileManager.deleteFromPath(context.originDownloadedPath)
    }
    if (context.previewTempPath) {
      taskLog(task, `cleanUpTask deleteFromPath path ${context.previewTempPath}`)
      FileManager.deleteFromPath(context.previewTempPath)
    }
    if (context.waterMarkSavePath) {
      taskLog(task, `cleanUpTask deleteFromPath path ${context.waterMarkSavePath}`)
      FileManager.deleteFromPath(context.waterMarkSavePath)
    }

    taskLog(task, `cleanUpTask DELETE record ${task.taskID} from DataBase`)
    DBManager.deleteDownloadRecordWithID(task.taskID)
  }

  //MARK: - Task Function

  /**
   * 将 task 加入数组，并对外发出通知
   * @memberof MediaDownloadManager
   */
  addTaskAndEmit = (task: MediaPipelineTask) => {
    this.tasks.push(task)
    DeviceEventEmitter.emit("MediaDownloadManagerTasksDidChangedNotify")
  }

  /**
   * 将 task 移除数组出并对外发送通知
   * @memberof MediaDownloadManager
   */
  removeTaskAndEmit = (task: MediaPipelineTask) => {
    let index = this.tasks.findIndex(obj => obj.taskID === task.taskID)
    if (index < 0) return
    this.tasks.splice(index, 1)
    DeviceEventEmitter.emit("MediaDownloadManagerTasksDidChangedNotify")
  }
}

// 默认全局只有一个 downloadManager 对象
const mediaDownloadManager = new MediaDownloadManager()
export default mediaDownloadManager