import MediaPipelineTask from './MediaPipelineTask'
import ZZLogger from 'SERVICES/logger/logger'

export function debugLog(...arg: any[]) {
  let info = "MediaPipeline:"
  arg.forEach(log => info += log);
  ZZLogger.log(info)
}
export function errorLog(...arg: any[]) {
  let info = "MediaPipeline:"
  arg.forEach(log => info += log);
  ZZLogger.log(info)
}

export function taskLog(task: MediaPipelineTask, ...arg:any[]) {
  debugLog(`taskID = ${task.taskID} | `, ...arg)
}

export function taskErrorLog(task: MediaPipelineTask, ...arg:any[]) {
  errorLog(`taskID = ${task.taskID} | `, ...arg)
}