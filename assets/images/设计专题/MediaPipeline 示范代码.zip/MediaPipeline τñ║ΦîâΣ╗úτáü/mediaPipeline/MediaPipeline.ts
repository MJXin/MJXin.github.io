import {concatMap} from 'rxjs/operators'

import MediaPipelineTask from './MediaPipelineTask'
import MediaPipelineStep, {MediaPipelineStepType} from './MediaPipelineStep'
import { ZMap } from 'TYPES/Map'

/**
 * pipeline 的任务类型
 */
export enum MediaPipelineType {
  /** WiFi: 下载缩率图，源图，处理源图及写入数据库 */
  WiFiDownloadAndWritePhoto = 'WiFiDownloadAndWritePhoto',
  /** WiFi: 下载缩率图，源视频及写入数据库 */
  WiFiDownloadAndWriteVideo = 'WiFiDownloadAndWriteVideo',
  /** WiFi: 下载缩略图，保存预览流及写入数据库*/
  WiFiWriteVideoWithPreview = 'WiFiWriteVideoWithPreview',
  /** WiFi: 下载源视频，更新数据库 */
  WiFiDownloadAndUpdateVideo = 'WiFiDownloadAndUpdateVideo',
}

/**
 * 下载图片缩略图，写入图片数据，下载源图，处理源图，更新数据库的流程
 */
const WiFiDownloadAndWritePhotoSteps = [
  MediaPipelineStepType.FetchMediaInfo,
  MediaPipelineStepType.DownloadMediaThumbnailByHttp,
  MediaPipelineStepType.SaveMediaThumbnail,
  MediaPipelineStepType.InsertMediaToDataBase,
  MediaPipelineStepType.DownloadMediaOriginByHttp,
  MediaPipelineStepType.AddWaterMark,
  MediaPipelineStepType.SaveMediaToAlbum,
  MediaPipelineStepType.UpdateDataBaseMedia,
]
/**
 * 下载视频缩略图，写入视频数据，下载视频，处理视频，更新数据库的流程
 */
const WiFiDownloadAndWriteVideoSteps = [
  // 这里有删除
]
/**
 * 下载视频缩略图，写入视频数据，保存视频预览流，更新数据库的流程
 */
const WiFiWriteVideoWithPreviewSteps = [
  // 这里有删除
]
/**
 * 下载源视频，更新数据库的流程
 */
const WiFiDownloadAndUpdateVideoSteps = [
  // 这里有删除
]

export const MediaPipelineTypeSteps: ZMap<MediaPipelineType, MediaPipelineStepType[]> = {
  [MediaPipelineType.WiFiDownloadAndWritePhoto]: WiFiDownloadAndWritePhotoSteps,
  [MediaPipelineType.WiFiWriteVideoWithPreview]: WiFiWriteVideoWithPreviewSteps,
  [MediaPipelineType.WiFiDownloadAndUpdateVideo]: WiFiDownloadAndUpdateVideoSteps,
  [MediaPipelineType.WiFiDownloadAndWriteVideo]: WiFiDownloadAndWriteVideoSteps,
  // 这里有删除
}

export default class MediaPipeline {

  readonly steps: MediaPipelineStep[]

  constructor(steps: MediaPipelineStep[]) {
    this.steps = steps
  }

  /**
   * Pipeline 构造的工厂方法
   *
   * @static
   * @param {MediaPipelineType} type
   * @returns
   * @memberof MediaPipeline
   */
  public static pipeLine(type: MediaPipelineType) {
    let steps: MediaPipelineStep[] = MediaPipelineTypeSteps[type].map(type => new MediaPipelineStep(type))
    return new MediaPipeline(steps)
  }

  /**
   * 根据当前的 Task 执行情况，返回剩余需要执行的步骤
   */
  public stepsForTask = (task: MediaPipelineTask) => {
    let beginIndex = 0
    if (task.isResume) {
      // 找到从哪个步骤开始
      beginIndex = Math.max(this.steps.findIndex(step => step.stepType == task.currentStage.stepType), 0)
    }
    return this.concatMapSteps(beginIndex)
  }

  private concatMapSteps = (from: number) => {  
    let subSteps = this.steps.slice(from)
    return subSteps.map(step => concatMap(step.process))
  }
}

