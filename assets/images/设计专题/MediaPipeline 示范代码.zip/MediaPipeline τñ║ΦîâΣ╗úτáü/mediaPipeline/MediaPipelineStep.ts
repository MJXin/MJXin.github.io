import * as Rx from 'rxjs'
import {Observable, Observer} from 'rxjs'
import {concatMap} from 'rxjs/operators'
import WaterMark from 'react-native-hc-watermark'

import {HTTPMediaDownloadTask, MediaDownloadType, USBMediaDownloadTask} from 'MEDIASERVER/MediaDownloadTask'
import DBManager from 'DATABASE/DBManager'
import Media from 'DATABASE/model/Media'
import {hoverMediaToMediaInfo} from 'UTILS/dataConversion/HoverMediaToDBMedia'
import MediaHelper from 'SERVICES/mediaHelper'
import FileManager, {FileType} from 'FILESYSTEM/FileManager'

import {MediaModels} from "DATABASE/model/MediaModels"
import {fetchMediaByName} from "MEDIASERVER"
import MediaPipelineTask from "SERVICES/mediaPipeline/MediaPipelineTask"
import {MediaPipelineErrorCode} from "SERVICES/mediaPipeline/MediapipelineError"
import {taskErrorLog, taskLog} from "SERVICES/mediaPipeline/Log"
import {Platform} from "react-native"
import NativeUtils, {BundleFileType} from "SERVICES/NativeUtils"
import {UserDefault} from "SERVICES/userDefault"
import MediaState = MediaModels.MediaState
import MediaType = MediaModels.MediaType

export enum MediaPipelineStepType {
  Init = "Init",
  CheckInProgressDuplication = "checkInProgressDuplication",
  FetchMediaInfo = "fetchMediaInfo",
  DownloadMediaThumbnailByHttp = "downloadMediaThumbnailByHttp",
  SaveMediaThumbnail = "saveMediaThumbnail",
  InsertMediaToDataBase = "insertMediaToDataBase",
  DownloadMediaOriginByHttp = "downloadMediaOriginByHttp",
  AddWaterMark = "addWaterMark",
  SaveVideoPreview = "saveVideoPreview",
  SaveMediaToAlbum = "saveMediaToAlbum",
  UpdateDataBaseMedia = "updateDataBaseMedia",
  // 这里有删除
  CleanUpAddMediaTask = "cleanUpAddMediaTask",
  SyncMediaInfoFromDataBase = "syncMediaInfoFromDataBase",
}

const StepProcesses: { [key: string]: (task: MediaPipelineTask) => Observable<MediaPipelineTask> } = {
  [MediaPipelineStepType.FetchMediaInfo]: fetchMediaInfo,
  [MediaPipelineStepType.DownloadMediaThumbnailByHttp]: downloadMediaThumbnailByHttp,
  [MediaPipelineStepType.SaveMediaThumbnail]: saveMediaThumbnail,
  [MediaPipelineStepType.InsertMediaToDataBase]: insertMediaToDataBase,
  [MediaPipelineStepType.DownloadMediaOriginByHttp]: downloadMediaOriginByHttp,
  [MediaPipelineStepType.AddWaterMark]: addWaterMark,
  [MediaPipelineStepType.SaveVideoPreview]: saveVideoPreview,
  [MediaPipelineStepType.SaveMediaToAlbum]: saveMediaToAlbum,
  [MediaPipelineStepType.UpdateDataBaseMedia]: updateDataBaseMedia,
  [MediaPipelineStepType.SyncMediaInfoFromDataBase]: syncMediaInfoFromDataBase,
  // 这里有删除
}


/**
 * 流水线中执行步骤的抽象类
 * @class MediaPipelineStep
 */
export default class MediaPipelineStep {

  constructor(type: MediaPipelineStepType) {
    this.stepType = type
  }

  stepType: MediaPipelineStepType

  process = (task: MediaPipelineTask): Observable<MediaPipelineTask> => {
    let observable = StepProcesses[this.stepType]
    return Rx.of(task).pipe(
      concatMap(this.updateTaskStage),
      concatMap(observable)
    )
  }

  updateTaskStage = (task: MediaPipelineTask) => {
    taskLog(task, `${this.stepType} started`)
    task.currentStage.updateCurrentStage(this.stepType)
    return Rx.of(task)
  }
}

/**
 * 获取 Media 详细信息
 *
 * @memberof MediaPipeline
 */
function fetchMediaInfo(task: MediaPipelineTask) {
  let {context} = task
  return Observable.create((observer: Observer<MediaPipelineTask>) => {
    task.didPauseTask = () => {observer.error(MediaPipelineErrorCode.pause)}
    task.didCancelTask = () => {observer.error(MediaPipelineErrorCode.interrupt)}
    fetchMediaByName(task.mediaName)
      .then(hoverMedia => {
        taskLog(task, 'fetchMediaInfo succeed with media:', JSON.stringify(hoverMedia, null, " "))
        context.mediaInfo = hoverMediaToMediaInfo(hoverMedia)
        observer.next(task)
        observer.complete()
      }).catch(error => {
      taskErrorLog(task, 'fetchMediaInfo error:', error)
      // 不详细处理网络错误，对外都归为一种
      observer.error(MediaPipelineErrorCode.fetchMediaInfoError)
    })
  })
}

/**
 * 下载 Media 缩率图
 *
 * @memberof MediaPipeline
 */
function downloadMediaThumbnailByHttp(task: MediaPipelineTask) {
  let {context} = task
  return Observable.create((observer: Observer<MediaPipelineTask>) => {
    task.didPauseTask = () => {observer.error(MediaPipelineErrorCode.pause)}
    task.didCancelTask = () => {observer.error(MediaPipelineErrorCode.interrupt)}

    let downloadTask = new HTTPMediaDownloadTask(task.mediaName, MediaDownloadType.Thumbnail)
    downloadTask.start().then(filePath => {
      taskLog(task, `downloadMediaThumbnail success path = ${filePath}`)
      context.thumbnailDownloadedPath = filePath
      observer.next(task)
      observer.complete()
    }).catch((error) => {
      // 不详细处理网络错误，对外都归为一种
      taskErrorLog(task, 'downloadMediaThumbnail error:', error)
      observer.error(MediaPipelineErrorCode.downloadMediaThumbnailError)
    })
  })
}

/**
 * 保存缩略图
 *
 * @memberof MediaPipeline
 */
function saveMediaThumbnail(task: MediaPipelineTask) {
  let {context} = task
  return Observable.create((observer: Observer<MediaPipelineTask>) => {
    task.didPauseTask = () => {observer.error(MediaPipelineErrorCode.pause)}
    task.didCancelTask = () => {observer.error(MediaPipelineErrorCode.interrupt)}

    if (!context.mediaInfo || !context.thumbnailDownloadedPath) {
      taskErrorLog(task, `saveMediaThumbnail media not existed`)
      observer.error(MediaPipelineErrorCode.saveThumbnailParamsError)
      return
    }
    MediaHelper.saveMedia(
      context.thumbnailDownloadedPath,
      task.mediaName,
      MediaState.Thumbnail,
      context.mediaInfo.type
    ).then(({assetID, path}) => {
      context.assetID = assetID
      context.thumbnailSavePath = path
      taskLog(task, `saveMediaThumbnail succeed with assetID = ${assetID}, path = ${path}`)
      observer.next(task)
      observer.complete()
    }).catch(error => {
      // 不详细处理保存错误，对外都归为一种
      taskErrorLog(task, 'saveMediaThumbnail error: ', error)
      observer.error(MediaPipelineErrorCode.saveMediaError)
    })
  })
}

/**
 * 下载 Media 源资源(HTTP 方式)
 *
 * @memberof MediaPipeline
 */
function downloadMediaOriginByHttp(task: MediaPipelineTask) {
  let {context} = task
  return Observable.create((observer: Observer<MediaPipelineTask>) => {
    if (!context.mediaInfo) {
      taskErrorLog(task, 'downloadMediaOriginByHttp error:', MediaPipelineErrorCode.downloadMediaOriginParamsError)
      observer.error(MediaPipelineErrorCode.downloadMediaOriginError)
      return
    }
    let downloadType: MediaDownloadType = context.mediaInfo.type == MediaType.Video ?
      MediaDownloadType.Video : MediaDownloadType.Photo
    let downloadTask = new HTTPMediaDownloadTask(task.mediaName, downloadType)
    FileManager.isEnoughStorageForMedia(context.mediaInfo.size)
      .then(isEnough => {
        if (!isEnough) return Promise.reject(MediaPipelineErrorCode.shortOfStorageError)
        return downloadTask.start()
      }).then(filePath => {
      taskLog(task, `downloadMediaOriginByHttp succeed path = ${filePath}`)
      context.originDownloadedPath = filePath
      task.currentStage.updateProgress(1)
      observer.next(task)
      observer.complete()
    }).catch((error) => {
      taskErrorLog(task, 'downloadMediaOriginByHttp error:', error)
      if (error == MediaPipelineErrorCode.shortOfStorageError) {
        observer.error(error)
      } else {
        // 不详细处理网络错误，对外都归为一种
        observer.error(MediaPipelineErrorCode.downloadMediaOriginError)
      }
    })

    // 更新 task 的进度
    downloadTask.progress = (received: number, total: number) => {task.currentStage.updateProgress(received / total)}

    task.didPauseTask = () => {
      downloadTask.pause()
      observer.error(MediaPipelineErrorCode.pause)
    }
    task.didCancelTask = () => {
      downloadTask.cancel()
      observer.error(MediaPipelineErrorCode.interrupt)
    }
  })
}

/**
 * 添加水印
 *
 * @memberof MediaPipeline
 */
function addWaterMark(task: MediaPipelineTask) {
  let {context} = task
  return Observable.create((observer: Observer<MediaPipelineTask>) => {
    if (!UserDefault.config().isWaterMarkEnable) {
      observer.next(task)
      observer.complete()
      return
    }
    task.didPauseTask = () => {observer.error(MediaPipelineErrorCode.pause)}
    task.didCancelTask = () => {observer.error(MediaPipelineErrorCode.interrupt)}
    if (!context.originDownloadedPath) {
      taskErrorLog(task, `addWaterMark originDownloadedPath not existed`)
      observer.error(MediaPipelineErrorCode.addWaterMarkParamsError)
      return
    }
    let input = context.originDownloadedPath
    let output: string
    FileManager.getMediaPath(FileType.WaterMark, task.mediaName)
      .then((path) => {
        output = path
        return NativeUtils.pathForResource("watermark", BundleFileType.PNG)
      }).then((path) => {
      return WaterMark.addWatermarkToImage(path, input, output)
    }).then(() => {
      context.waterMarkSavePath = output
      taskLog(task, `addWaterMark succeed path:`, output)
      observer.next(task)
      observer.complete()
    }).catch((error) => {
      taskErrorLog(task, 'addWaterMark error:', error)
      observer.error(MediaPipelineErrorCode.addWaterMarkError)
    })
  })
}

/**
 * 保存图片到相册
 *
 * @memberof MediaPipeline
 */
function saveMediaToAlbum(task: MediaPipelineTask) {
  let {context} = task
  return Observable.create((observer: Observer<MediaPipelineTask>) => {
    task.didPauseTask = () => {observer.error(MediaPipelineErrorCode.pause)}
    task.didCancelTask = () => {observer.error(MediaPipelineErrorCode.interrupt)}

    if (!context.mediaInfo || !context.originDownloadedPath) {
      taskErrorLog(task, `saveMediaToAlbum media not existed`)
      observer.error(MediaPipelineErrorCode.saveMediaParamsError)
      return
    }
    FileManager.existAtPath(context.waterMarkSavePath)
      .then(isExist => {
        return isExist ? context.waterMarkSavePath! : context.originDownloadedPath!
      }).then(originPath => {
      return MediaHelper.saveMedia(
        originPath,
        task.mediaName,
        MediaState.Proto,
        context.mediaInfo!.type
      )
    }).then(({assetID, path}) => {
      //android 更新DCIM系统相册
      if (Platform.OS === 'android' && path) {
        NativeUtils.modifyPhotoDate(path)
        NativeUtils.updateDCIM(path)
      }
      context.mediaInfo!.assetID = assetID
      context.mediaInfo!.state = MediaState.Proto
      context.originSavePath = path
      taskLog(task, `saveMediaToAlbum success wtih assetID = ${assetID}, path = ${path}`)
      observer.next(task)
      observer.complete()
    }).catch(error => {
      // 不详细处理保存错误，对外都归为一种
      taskErrorLog(task, 'saveMediaToAlbum error:', error)
      observer.error(MediaPipelineErrorCode.saveMediaError)
    })
  })
}

/**
 * 保存视频预览流
 *
 * @memberof MediaPipeline
 */
function saveVideoPreview(task: MediaPipelineTask) {
  let {context} = task
  return Observable.create((observer: Observer<MediaPipelineTask>) => {
    task.didPauseTask = () => {observer.error(MediaPipelineErrorCode.pause)}
    task.didCancelTask = () => {observer.error(MediaPipelineErrorCode.interrupt)}

    if (!context.mediaInfo) {
      taskErrorLog(task, `saveVideoPreview mediaInfo or previewTempPath not existed`)
      observer.error(MediaPipelineErrorCode.saveVideoPreviewParamsError)
      return
    } else if (!context.previewTempPath) {
      taskLog(task, `saveVideoPreview pass because of previewTempPath is undefine`)
      observer.next(task)
      observer.complete()
      return
    }
    FileManager.moveFileFromPath(context.previewTempPath, FileType.PreviewVideo, task.mediaName)
      .then(() => {
        taskLog(task, `saveVideoPreview succeed path:${FileManager.getMediaPath(FileType.PreviewVideo, task.mediaName)}`)
        context.mediaInfo!.state = MediaState.Preview
        observer.next(task)
        observer.complete()
      })
      .catch(error => {
        // 不详细处理保存错误，对外都归为一种
        taskErrorLog(task, 'saveVideoPreview error:', error)
        observer.error(MediaPipelineErrorCode.saveVideoPreviewError)
      })
  })
}

const VIDEO_DURATION_THRESHOLD = 0.8 //丢帧率的阈值
/**
 * 保存视频预览流同时判断视频丢包率
 *
 * @memberof MediaPipeline
 */
function saveVideoPreviewWithDurationJudgement(task: MediaPipelineTask) {
  let {context} = task
  return Observable.create((observer: Observer<MediaPipelineTask>) => {
    task.didPauseTask = () => {observer.error(MediaPipelineErrorCode.pause)}
    task.didCancelTask = () => {observer.error(MediaPipelineErrorCode.interrupt)}

    if (!context.mediaInfo) {
      taskErrorLog(task, `saveVideoPreview mediaInfo or previewTempPath not existed`)
      observer.error(MediaPipelineErrorCode.saveVideoPreviewParamsError)
      return
    } else if (!context.previewTempPath) {
      taskLog(task, `saveVideoPreview pass because of previewTempPath is undefine`)
      observer.next(task)
      observer.complete()
      return
    }

    //通过时长判断视频是否丢帧太多
    NativeUtils.getVideoDuration(context.previewTempPath)
      .then((previewDuration: number) => {
        let originVideoDuration = context.mediaInfo?.duration
        if (!originVideoDuration) {
          throw MediaPipelineErrorCode.originVideoDurationUnknownError
        }
        let durationCompare = previewDuration * 1000 / originVideoDuration > VIDEO_DURATION_THRESHOLD

        if (durationCompare) {
          return FileManager.moveFileFromPath(context.previewTempPath!, FileType.PreviewVideo, task.mediaName)
        } else {
          throw MediaPipelineErrorCode.previewVideoDurationError
        }
      })
      .then(() => {
        taskLog(task, `saveVideoPreview succeed path:${FileManager.getMediaPath(FileType.PreviewVideo, task.mediaName)}`)
        context.mediaInfo!.state = MediaState.Preview
        observer.next(task)
        observer.complete()
      })
      .catch((error: Error) => {
        taskErrorLog(task, `preview video duration checking failed, without preview video`)
        observer.error(error)
      })
  })
}

function syncMediaInfoFromDataBase(task: MediaPipelineTask) {
  let {context} = task
  return Observable.create((observer: Observer<MediaPipelineTask>) => {
    task.didPauseTask = () => {observer.error(MediaPipelineErrorCode.pause)}
    task.didCancelTask = () => {observer.error(MediaPipelineErrorCode.interrupt)}

    let media = DBManager.queryMediaWithName(task.mediaName)
    if (!media) {
      taskErrorLog(task, `getMediaInfoFromDataBase error: media does not existed`)
      observer.error(MediaPipelineErrorCode.mediaDoesNotInDataBase)
    } else {
      context.mediaID = media.mediaID
      context.mediaInfo = Media.toInfo(media)
      observer.next(task)
      observer.complete()
    }
  })
}

/**
 * 在数据库中写入图片
 *
 * @memberof MediaPipeline
 */
function insertMediaToDataBase(task: MediaPipelineTask) {
  let {context} = task
  return Observable.create((observer: Observer<MediaPipelineTask>) => {
    task.didPauseTask = () => { observer.error(MediaPipelineErrorCode.pause) }
    task.didCancelTask = () => { observer.error(MediaPipelineErrorCode.interrupt)}
    if (!context.mediaInfo) {
      taskErrorLog(task, `insertMediaToDataBase mediaInfo not existed`)
      observer.error(MediaPipelineErrorCode.insertMediaParamsError)
    } else {
      let exitMedia = DBManager.queryMediaWithName(context.mediaInfo.name)
      let mediaID = exitMedia ? exitMedia.mediaID : undefined
      taskLog(task, 'insertMediaToDataBase has exited media? mediaID = ', mediaID)
      taskLog(task, 'insertMediaToDataBase ', JSON.stringify(context.mediaInfo, null, " "))
      context.mediaInfo.date = new Date()
      let media = DBManager.updateOrInsertMedia(Media.media(context.mediaInfo), mediaID)
      taskLog(task, 'insertMediaToDataBase succeed with media', JSON.stringify(media, null, " "))
      context.mediaID = media.mediaID
      observer.next(task)
      observer.complete()
    }
  })
}

/**
 * 更新数据库的数据
 *
 * @memberof MediaPipeline
 */
function updateDataBaseMedia(task: MediaPipelineTask) {
  let {context} = task
  return Observable.create((observer: Observer<MediaPipelineTask>) => {
    task.didPauseTask = () => { observer.error(MediaPipelineErrorCode.pause) }
    task.didCancelTask = () => { observer.error(MediaPipelineErrorCode.interrupt)}
    if (!context.mediaID) {
      let media = DBManager.queryMediaWithName(task.mediaName)
      context.mediaID = media ? media.mediaID : undefined
    }
    if (!context.mediaInfo || !context.mediaID) {
      taskErrorLog(task, `updateDataBaseMedia media not existed`)
      observer.error(MediaPipelineErrorCode.updateDataBaseMediaParamsError)
      return
    } else {
      let media = DBManager.updateMedia(context.mediaID, Media.media(context.mediaInfo))
      taskLog(task, 'updateDataBaseMedia succeed with media', JSON.stringify(media, null, " "))
      context.mediaID = media.mediaID
      observer.next(task)
      observer.complete()
    }
  })
}
