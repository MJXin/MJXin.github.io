import {MediaInfo} from 'DATABASE/model/Media'
import * as Rx from 'rxjs'
import {BehaviorSubject} from 'rxjs'
import MediaPipeline, {MediaPipelineType} from './MediaPipeline'
import {MediaPipelineStepType} from "./MediaPipelineStep"
import {taskErrorLog} from "./Log"

/**
 * Task 中保存的上下文
 *
 * @interface MediaPipelineTaskContext
 */
export interface MediaPipelineTaskContext {
  /** 当前 media 的临时数据 */
  mediaInfo?: MediaInfo
  /** 当前数据库中的 media (只能从数据库中拿，不要手动修改 media 的值) */
  mediaID?: number

  //MARK: 下载过程中用到的路径

  /** 下载后临时保存的缩略图地址 */
  thumbnailDownloadedPath?: string
  /** 下载后临时保存的源图地址 */
  originDownloadedPath?: string
  /** 预览流的临时地址 */
  previewTempPath?: string
  /** 保存进 iOS 相册后的 MediaID */
  assetID?: string
  /** 保存后的源文件路径 */
  originSavePath?: string
  /** 保存后的缩率图路径 */
  thumbnailSavePath?: string
  /** 保存后的预览流路径 */
  previewSavePath?: string
  /** 保存后的水印路径 */
  waterMarkSavePath?: string
}

export interface MediaPipelineTaskState {
  isWorking: boolean,
  stepType: MediaPipelineStepType
  context: MediaPipelineTaskContext
  stepProgress?: number
}

/**
 * 当前 mediaPipeline 执行的步骤
 */
class MediaPipelineTaskStage {

  startStep: MediaPipelineStepType
  stepType: MediaPipelineStepType = MediaPipelineStepType.Init
  stepIndex: number = 0
  stepProgress?: number
  didUpdateStage?: () => void

  constructor(type: MediaPipelineStepType, progress: number = 0) {
    this.stepType = type
    this.startStep = type
    this.stepProgress = progress
    this.stepIndex = 0
  }

  readonly updateProgress = (progress: number) => {
    this.stepProgress = progress
    this.didUpdateStage && this.didUpdateStage()
  }

  readonly updateCurrentStage = (type: MediaPipelineStepType, haveProgress: boolean = false) => {
    this.stepIndex += 1
    this.stepType = type
    this.stepProgress = haveProgress ? 0 : undefined
    this.didUpdateStage && this.didUpdateStage()
  }
}

/** MediaPipeline 中正在执行的任务 */
export default class MediaPipelineTask {
  readonly taskID: number
  readonly mediaName: string
  readonly pipeLineType: MediaPipelineType
  readonly date: Date
  /** 是否是恢复执行的 task */
  private _isResume: boolean = false
  /** 是否正在执行中 */
  private _isWorking: boolean = false
  private _state: BehaviorSubject<MediaPipelineTaskState>
  /** 当前执行的步骤名称 */
  currentStage: MediaPipelineTaskStage
  /** 当前 MediaPipeline 临时保存的上下文 */
  context: MediaPipelineTaskContext

  constructor(
    taskID: number,
    mediaName: string,
    type: MediaPipelineType,
    stage: MediaPipelineTaskStage = new MediaPipelineTaskStage(MediaPipelineStepType.Init),
    context: MediaPipelineTaskContext = {},
    date: Date = new Date(),
    isResume: boolean = false) {
    this.taskID = taskID
    this.mediaName = mediaName
    this.pipeLineType = type
    this.currentStage = stage
    this.context = context
    this.date = date
    this._isResume = isResume
    this._state = new BehaviorSubject<MediaPipelineTaskState>(this.getTaskState())
    this.currentStage.didUpdateStage = () => {
      this.state.next(this.getTaskState())
    }
  }

  static taskFromRecord(record: MediaDownloadRecord): MediaPipelineTask {
    return new MediaPipelineTask(
      record.downloadID,
      record.mediaName,
      record.pipeLineType,
      new MediaPipelineTaskStage(record.currentStep, record.currentStepProgress),
      record.context ? JSON.parse(record.context) : undefined,
      record.date,
      true,
    )
  }

  get state(): BehaviorSubject<MediaPipelineTaskState> {
    return this._state
  }

  get isResume(): boolean {
    return this._isResume
  }

  get isWorking(): boolean {
    return this._isWorking
  }

  didPauseTask?: () => void

  didCancelTask?: () => void

  /**
   * 在指定的 pipeline 中执行  task (可用于重新开始执行)
   */
  readonly runInPipeline = (pipeLine: MediaPipeline): BehaviorSubject<MediaPipelineTaskState> => {
    if (this.isWorking) {
      taskErrorLog(this, "task 已经在执行中")
      return this.state
    }
    this._isWorking = true
    this._state = new BehaviorSubject<MediaPipelineTaskState>(this.getTaskState())

    Rx.of(this).pipe(
      ...pipeLine.stepsForTask(this)
    ).subscribe({
      next: (task: MediaPipelineTask) => {  
        //删掉了
      },
      error: (error:any) => {
        this._isWorking = false
        this.state.error(error)
      },
      complete: () => {
        this._isWorking = false
        this.state.complete()
      },
    }) 
    return this.state
  }

  readonly pause = () => {
    if(!this._isWorking)  {
      taskErrorLog(this, "task 已经在暂停中")
      return
    }
    this._isWorking = false
    this._isResume = true
    this.state.next(this.getTaskState())
    this.didPauseTask && this.didPauseTask()
  }

  readonly cancel = () => {
    if(!this._isWorking)  {
      taskErrorLog(this, "task 已经被取消")
      return
    }
    this._isWorking = false
    this._isResume = true
    this.state.next(this.getTaskState())
    this.didCancelTask && this.didCancelTask()
  }

  private getTaskState = (): MediaPipelineTaskState => {
    let {currentStage, isWorking, context} = this
    let {stepType, stepProgress} = currentStage
    return {stepType, stepProgress, isWorking, context}
  }
}