enum MediaPipelineErrorCode {
  pause = -1,
  interrupt = -2,
  taskIsExisted = 1,
  taskIsStarted = 2,
  // 这里有删除
  originVideoDurationUnknownError = 22

}
export {MediaPipelineErrorCode}